![Mrucznik Role Play](https://i.imgur.com/3BFCOVu.png)

## Lista bez unbana
Liderzy w złej dziedzinie - **brak unbana** na forum.
* [Gliniaszv1](https://mrucznik-rp.pl/user/3703-gliniaszv1/) - 51 warnów, multikonta, obrazy ekipy, spam na forum
* [bartek luccese](https://mrucznik-rp.pl/user/347-bartek-luccese/)- iplogger w profilu, 38 warnów, rozsiewanie malware
* [ezowski](https://mrucznik-rp.pl/user/3460-czarnuch-ezo/) - liczne multikonta, 22 warny, burdel na forum
* [Elvis Blade](https://mrucznik-rp.pl/user/4438-elvis-blade/)/[Trevor Blade](https://mrucznik-rp.pl/user/4480-trevor-blade/) - liczne multikonta, obrazy, hejt, prowokacje, szkalowanie Jana Pawła II
* [Caboty](https://mrucznik-rp.pl/user/628-caboty/) - rozsiewanie malware, reklamy
* [kolanko rpk](https://mrucznik-rp.pl/user/4578-kolanko-rpk/)/[kolanko](https://mrucznik-rp.pl/user/1672-kolanko/)/bonus rpk/[Tomasz Tomaszewski](https://mrucznik-rp.pl/user/8221-tomasz-tomaszewski/) - obrazy, spam, trolling, liczne multikonta, ataki na forum, włamy
* [DagerDJ](https://mrucznik-rp.pl/user/2785-dagerdj/)/[iGrubySSG](https://mrucznik-rp.pl/user/3270-igrubyssg/) - rozsiewanie/sprzedawanie keyloggera jako hacka do kasyna, multikonta
* [Azzam](https://mrucznik-rp.pl/user/4191-azzam/) - liczne multikonta, 30 warnów, szkalowanie ekipy forum, burdel na forum, piractwo, udostępnianie nielegalnych obrazów systemów
* [Bagieta](https://mrucznik-rp.pl/user/769-bagieta/) - liczne obrazy administracji i użytkowników, brak kultury, multikonta, propagowanie osoby prywatnej (tematy szkalujące realnego gracza), wyśmiewanie się, poniżanie, wyzwiska.
* [Arwex](https://mrucznik-rp.pl/user/408-arwex/) - multikonta, treści pornograficzne
* [Dyzmiontko](https://mrucznik-rp.pl/user/663-dyzmiontko/) - 38 warnów, liczne obrazy, brak kultury, groźby, rozpowszechnianie wizerunku gracza
* [glo up](https://mrucznik-rp.pl/user/7840-glo-up/) - obrazy, reklama konkurencji
* [domciodog](https://mrucznik-rp.pl/user/262-domciodog/) - 23 warny, obrazy użytkowników i administracji
* [Andrzej](https://mrucznik-rp.pl/user/287-andrzej/) - 64 warny, trolling, oszustwa, wykorzystywanie wizerunku graczy (przerabianie & wklejanie twarzy), ciągły offtop, celowe błędy ortograficzne, śmieciowe tematy, wulgryzmy
* [ALIBXBA](https://mrucznik-rp.pl/user/234-alibxba/) - szkodnik no. 1, top 1 warnów [71 notek] 31 marca 2017, liczne obrazy serwera, administracji, graczy, offtop, hejt, brak kultury
* [Vegan](https://mrucznik-rp.pl/user/1509-vegan/) - rozpowszechnianie filmów z czitowaniem, boruty, treści pornograficzne, liczne obrazy, trolling
* [plewa](https://mrucznik-rp.pl/user/368-plewa/) - liczne obrazy, multikonta, nagminny offtop, spora kolekcja warnów
* [gandalf](https://mrucznik-rp.pl/user/3465-gandalf/) - liczne obrazy i multikonta, offtop, ogromna kolekcja warnów (67 - zaraz za ALIBXBA)
* [myszka miki toja/emiltoja](https://mrucznik-rp.pl/user/8499-paprotka-toja/) - wrzucanie fotek sandry, masa warnów, liczne multikonta, brak poprawy
* [psz](https://mrucznik-rp.pl/user/417-psz/) - ddos forum, szkalowanie papieża, masa multikont, handel kontem, szkodnik no. 1
* [ala](https://mrucznik-rp.pl/user/3272-ala/) - 52 warny (2 grudnia 2017), liczny offtop, celowe błędy ortograficzne, obrazy, brak szans na poprawe, udostępnianie prywatnej korespondencji użytkowników
* [Sevenity](https://mrucznik-rp.pl/user/584-sevenity/) - udostępnianie prywatynch danych użytkownika, nadużywanie uprawnień, obrazy, włam na konto byłego administratora, wyciek danych ze slacka, zmarnowanie szansy i złamanie zasad cyrografu
* [qetsiyah](http://mrucznik-rp.pl/user/252-qetsiyah/)/[Beverly Rockmond](https://mrucznik-rp.pl/user/14628-beverly-rockmond/) sell hajsu, lista bez ub, liczne multikonta, powrót po definitywnym usunięciu konta
* [kotgio](https://mrucznik-rp.pl/user/2428-kotgio/) - sell hajsu, masowe multikonta
* [Galway Girl](https://mrucznik-rp.pl/user/10380-galway-girl/) - liczny offtop, obrazy, kolekcja warnów, niewykorzystana szansa.
* [Oficer](http://mrucznik-rp.pl/user/98-oficer/) - liczne i nagminne obrazy, szerzenie nienawiści, offtop, trolling, 57 warnów (16-06-2018), brak jakichkolwiek oznak poprawy
* [Poldi](https://mrucznik-rp.pl/user/17425-poldi/)/[CHIPS](https://mrucznik-rp.pl/user/17411-chips/)/[PanTadeusz](https://mrucznik-rp.pl/user/16423-pantadeusz/)/[_NEKTAR_](https://mrucznik-rp.pl/user/15101-nektar/)/[_Yamato_](https://mrucznik-rp.pl/user/14930-yamato/)/[_ROGAL_DDL_](https://mrucznik-rp.pl/user/14313-rogal-ddl/)/[Despacito](https://mrucznik-rp.pl/user/13627-despacito/)/[BosiakowieC](https://mrucznik-rp.pl/user/12802-bosiakowiec/)/[_BosioK_](https://mrucznik-rp.pl/user/11056-bosiok/)/[LonsdaLE](https://mrucznik-rp.pl/user/9161-lonsdale/)/[XardasoBosioK](https://mrucznik-rp.pl/user/8816-xardasobosiok/)/[Wake UP](https://mrucznik-rp.pl/user/6177-wake-up/)/[ DaxleR](https://mrucznik-rp.pl/user/230-daxler/) - nagminne multikonta
* [kildra](https://mrucznik-rp.pl/user/7824-kildra/) - multikonta, liczne wulgaryzmy
* [dinol mie swendzi](https://mrucznik-rp.pl/user/497-dinol-mie-swendzi/) aka albertos - spora kartoteka, reklama konkurencji, liczne obrazy i wulgaryzmy, offtop, brak kultury, trolling, brak szans na poprawe
* [Shaggy](https://mrucznik-rp.pl/user/325-shaggy/) - gigantyczna kartoteka, brak kultury, liczne wulgaryzmy i obrazy, offtop, reklama konkurencji, mulikonta, brak szans na poprawe
* [Snopek](http://mrucznik-rp.pl/user/735-snopek-essa/) - gigantyczna kartoteka, brak kultury, liczne wulgaryzmy i obrazy, offtop, reklama konkurencji, mulikonta, brak szans na poprawe
* [Konto Dezaktywowane (Campil Trooper/chemik/XXXHZXXX)](https://mrucznik-rp.pl/user/6917-konto-dezaktywowane/) - gigantyczna kartoteka, reklama konkurencji, liczne obrazy i wulgaryzmy, multikonta, brak szans na poprawe
* [Connasse/Hey/Dżemik](https://mrucznik-rp.pl/user/4336-connasse/) - 72 notek (2 grudnia 2017), celowe błędy ortograficzne, offtop, spam, trolling, brak kultury, szambo na forum, obrazy, totalny brak poprawy
* [Koraliczek](https://mrucznik-rp.pl/user/15075-koraliczek/) - udostępnianie i rozpowszechnianie zdjęć oraz danych osobowych usera forum
* [komunista dowell](https://mrucznik-rp.pl/user/2127-komunista-dowell/) - liczne obrazy, 50 notatek (11.02.2018), offtop, multikonta, spam
* [cymbalista vjed/niceczłowiek/5777](https://mrucznik-rp.pl/user/8615-cymbalista-vjed/) - udostępnianie kodu mrucznik 2.5
* [123](https://mrucznik-rp.pl/user/9238-123/)/[three5ixtyy](https://mrucznik-rp.pl/user/7961-three5ixtyy/)/[bishop](https://mrucznik-rp.pl/user/13561-bishop/)/[Brylson12](https://mrucznik-rp.pl/user/18610-brylson12/) -
ogromna ilość warnów, liczne multikonta, adresy vpn utrudniające weryfikację, serwerowa lista bez ub, szkodnik n01
* [hesho](https://mrucznik-rp.pl/user/5669-hesho-g-star/)- 67 warnów (2 grudnia 2017), liczne orbazy, brak kultury, nagminne wulgaryzmy, ogólne szambo | awans na liste bez ub z listy ostatniej szansy, kolejne obrazy, kolejne multikonta, kompletny brak resocjalizacji
* [kozan](https://mrucznik-rp.pl/user/9977-kozanosky/) - 62 warnów (25 grudnia 2018), nadmierne i masowe obrazy, publikowanie cudzych zdjęć, masa offtopu, ban po liście ostatniej szansy, wstawianie treści erotycznych
* [JaszczuR](https://mrucznik-rp.pl/topic/76814-oban-jaszczur/) - obraza członka ekipy forum (długa wiązanka), życzenie śmierci - więcej info w warnie 20762
* [szyla](https://mrucznik-rp.pl/user/17551-szyla/) - gigantyczna ilość multikont
* [Ksenon](https://mrucznik-rp.pl/user/14795-ksenon/) - gigantyczna kartoteka, liczne obrazy i wulgaryzmy, brak szacunku do administracji jak i do innych użytkowników, liczne MK po otrzymaniu bana
* [rappa](https://mrucznik-rp.pl/user/16099-rappa/) - gigantyczna kratoteka, liczne obrazy i wulgaryzmy, pokaźne ilości multikont

## Kandydaci do listy bez unbana
Next time ban wbity prosto w czoło, nawet za najmniejszą pierdołę. Otrzymany ban jest równoznaczny z automatycznym awansem użytkownika na listę bez unbana.
* [JOSEF MENGELE/wojtek brooklyn/wojtek brkln](https://mrucznik-rp.pl/user/569-wojtek-brkln/) - liczne obrazy, liczne multikonta, offtop, brak jakiejkolwiek poprawy, gigantyczna kartoteka, 62 warnów (2 grudnia 2017), liczne obrazy, offtop, brak kultury, nagminne wulgaryzmy, ogólne szambo
* [\_Daniel\_](https://mrucznik-rp.pl/user/229-daniel/) - gigantyczna kartoteka, liczne obrazy, offtop, liczne wulgaryzmy, brak szans na poprawe
* [Bonger](https://mrucznik-rp.pl/user/453-bonger/) - 33 warny, liczne obrazy, multikonta, rozpowszechnianie logów serwerowych, dyskryminacja rasowa
* [jmpr ue](http://mrucznik-rp.pl/user/1175-jmpr-ue/) - 60 warnów (2 grudnia 2017), obrazy, offtop, brak poprawy, ogólne szkodzenie
* [\_Patrykoo\_](http://mrucznik-rp.pl/user/150-patrykoo/) - 56 warnów (2 grudnia 2017), liczne obrazy, offtop, nagminne wulgaryzmy, brak poprawy
* [fidif](https://mrucznik-rp.pl/user/306-fidif/) - 52 warny (2 grudnia 2017), masa notatek za orbazy, brak poprawy, offtop, totalny brak kultury i szans na poprawe
* [Pan Morisson](https://mrucznik-rp.pl/user/531-pan-morisson/) - 51 warnów (2 grudnia 2017), liczny offtop, obrazy, ogólne szambo, brak poprawy
* [en6x](http://mrucznik-rp.pl/user/4791-en6x/) - 49 warnów (2 grudnia 2017), liczne obrazy, offtop, brak szansy na poprawe
* [LuuckyDice](https://mrucznik-rp.pl/user/8703-luuckydice/) - liczne obrazy, offtop, liczne wulgaryzmy, gigantyczna kartoteka,
* [OYCHE DONIZ](http://mrucznik-rp.pl/user/911-oyche-doniz/) - gigantyczna kartoteka, liczne obrazy, offtop, prowokacje, brak kultury
* [don faraone](https://mrucznik-rp.pl/user/1119-lil-frachty/) - gigantyczna kartoteka, offtop, liczne obrazy i wulgaryzmy, treści pornograficzne, brak kultury, vpn
* [PRT](https://mrucznik-rp.pl/user/267-prt/) - gigantyczna kartoteka, offtop, liczne i masowe obrazy, brak kultury
* [Mistrz](https://mrucznik-rp.pl/user/1583-mistrz/) - gigantyczna kartoteka, liczne multikonta, liczne i nagminne obrazy/wulgaryzmy, brak kultury
* [levisjeans/nexiv/levisj](https://mrucznik-rp.pl/user/3388-etylonorheksedron/) - spora kartoteka, offtop, liczne obrazy, nabijanie postów, multikonta
* [sasquatch/młody sasku](http://mrucznik-rp.pl/user/608-sasquatch/) - spora kartoteka, liczne i nagmine obrazy/wulgaryzmy, offtop, pornografia
* [David King (David\_/BooYah)](http://mrucznik-rp.pl/user/605-david-king/) - spora kartoteka, liczne i nagminne obrazy, offtop
* [habemus krzysztof/hersh](https://mrucznik-rp.pl/user/3899-habemus-krzysztof/) - spora kartoteka, liczne obrazy, straszaki
* [Holltrailer](http://mrucznik-rp.pl/user/359-holltrailer/) - spora kartoteka, offtop, multikonta, liczne obrazy, wulgaryzmy
* [KobaltowyEryk/AlbertStulej](https://mrucznik-rp.pl/user/301-kobaltowyeryk/) - masa multikont, offtop, obrazy
* [PHC](https://mrucznik-rp.pl/user/194-phc/) - udostępnianie i rozpowszechnianie zdjęć oraz danych osobowych usera forum
* [Bleku/Blekuś](https://mrucznik-rp.pl/user/9598-bleku%C5%9B/) - udostępnianie i rozpowszechnianie zdjęć oraz danych osobowych usera forum
* [matewowo](https://mrucznik-rp.pl/user/9385-matewowo/)/[ven0m](https://mrucznik-rp.pl/user/17818-ven0m/) - spora kartoteka, nagminne obrazy, offtop, liczne wulgaryzmy, multikonta



## Na celowniku
Brak pobłażliwości - kary śrubowane za najmniejsze pierdoły.
* [marsjanin](http://mrucznik-rp.pl/user/843-marsjanin/)
* [Konradek](http://mrucznik-rp.pl/user/176-konradek/)
* [\_Klemuś\_](http://mrucznik-rp.pl/user/145-klemuś/)
* [Carlito](http://mrucznik-rp.pl/user/94-carlito/)
* [U5S8\_E2R1](http://mrucznik-rp.pl/user/5821-u5s8-e2r1/)
* [creey](http://mrucznik-rp.pl/user/56-creey/)
* [Shinigami](http://mrucznik-rp.pl/user/114-shinigami/)
* [kkuubbaa](http://mrucznik-rp.pl/user/557-jjnsz/)
* [DOPEHOOD](http://mrucznik-rp.pl/user/619-dopehood/)
* [szefuncio](https://mrucznik-rp.pl/user/1330-szefuncio/)
* [sh0z](https://mrucznik-rp.pl/user/172-sh0z/)/[mvx](https://mrucznik-rp.pl/user/14696-mvx/)
* [użytkownik pepek](https://mrucznik-rp.pl/user/84-u%C5%BCytkownik-pepek/)/[pajac](https://mrucznik-rp.pl/user/14589-pajac/)
* [Stróż Prowa](https://mrucznik-rp.pl/user/960-str%C3%B3%C5%BC-prowa/)
* [Bubi](https://mrucznik-rp.pl/user/564-bubi/)
* [0\_Tomek](https://mrucznik-rp.pl/user/8216-0-tomek/)
* [kkuubbaa](https://mrucznik-rp.pl/user/557-kkuubbaa/)
* [J rrye](https://mrucznik-rp.pl/user/78-j-rrye/)
* [K E V L A R](https://mrucznik-rp.pl/user/7632-k-e-v-l-a-r/)
* [KVMIL](https://mrucznik-rp.pl/user/1187-kvmil/)
* [Bradus/Braduś/Corleone](https://mrucznik-rp.pl/user/384-bradus/)
* [Czacha/Więzień] (https://mrucznik-rp.pl/user/15102-czacha/) / (https://mrucznik-rp.pl/user/19671-wi%C4%99zie%C5%84/)
