# Forumowe cyrografy

| ID | nick_ic | name | members_display_name | Data | Poręczyciel | Poręczenie | Obowiązki |
|----|:-------:|:----:|:--------------------:|:----:|:-----------:|:----------:|:----------|
| 1 | Andrew Leppere | Andrzej Lepper | [Andrzej](https://mrucznik-rp.pl/user/287-andrzej/) | 2018-08-12 | Mia Montoya ([mija](https://mrucznik-rp.pl/user/2750-mija/)) | [IMG](https://i.imgur.com/X31UjHq.png) - [PW](https://mrucznik-rp.pl/index.php?app=members&module=messaging&section=view&do=showConversation&topicID=157486) | prowadzenie stacji radiowej, tworzenie zestawień przebojów, kontynuacja gazety "Śledź", tworzenie artykułów politycznych, okazjonalne tworzenie filmików
