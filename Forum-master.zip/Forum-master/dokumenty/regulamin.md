# Regulamin forum Mrucznik Role Play

## Wstęp regulaminu
* Nowo zarejestrowany użytkownik automatycznie akceptuje regulamin forum oraz politykę prywatności.
* Nowo zarejestrowany użytkownik jest automatycznie przekierowywana na rangę jako użytkownik forum, który jest zobowiązany do przestrzegania punktów zawartych w regulaminie, dodatkowo jest świadomy, że jego konto może zostać odcięte z możliwego dostępu z podanych powodów.
* Każdy użytkownik jest zobowiązany do zabezpieczenia swojego konta globalnego hasłem, którego posiadać i znać może tylko osoba posiadająca dostęp do konta, użytkownik ponosi odpowiedzialność za czyny wynikające z jego winy, administracja nie ponosi odpowiedzialności za błędy użytkowników oraz nie zwraca szkód.
* Administracja forum, zarząd serwera zastrzega sobie prawo w ingerencję w konta użytkowników oraz zastrzega prawo do kasacji kont, użytkownik jest w pełni świadomy, że konto nie może zostać skasowane za jego prośbą - wszelkie dane są chronione i przechowywane, dane nie są udostępniane w żaden sposób dla osób trzecich.
* Administracja i inne grupy zastrzega sobie prawo do udostępniania danych o użytkownikach forum {adresy ip, e-maile, loginy, dane logowań, hosty}.
* Treści widoczne na forum, regulaminy, działy są ujęte prawami autorskimi.
* Treści, które mają na celu promocję innych projektów są surowo zabronione.
* Za czyny, które nie zostały wymienione w punktach regulaminu decyzję o ukaraniu użytkownika (i jego karze) podejmuje moderator za zgodą Administratora Forum.
* Użytkownik jest zobowiązany do uzupełnienia pełnymi danymi z serwera gry SA-MP jakim jest Mrucznik Role Play (samp.mrucznik-rp.pl), pod polem [Nick IC]. Oszustwa są surowo zabronione i karane.

## Korzystanie z forum Mrucznik Role Play
* Na forum www.mrucznik-rp.pl, z jednego konta globalnego może korzystać tylko i wyłącznie jedna osoba, zabrania się udostępniania konta globalnego dla osób trzecich, podawania danych do logowania na stronę WWW. Zabrania się również tworzenia multikont na forum. Jeśli przypadkiem jest współdzielenie swojego łącza internetowego, dany użytkownik jest zobowiązany do zgłoszenia takiego czynu w specjalnym temacie. (Przejdź do tematu). Za brak wpisu w temacie o współdzieleniu łącza, karą może być nawet odcięcie od dostępu do forum.
* Użytkownik jest w pełni świadomy, że jego konto globalne za złamanie regulaminu forum może zostać zablokowane, zawieszone, zawieszona możliwość pisania na forum, bądź tworzenia zawartości, wycięcia IP z serwera WWW na czas podany przez moderatora, który nadał karę.
* Zakazuje się zamieszczania propozycji do czynów nielegalnych i niezgodnych z Polskim prawem.
* Zakazuje się zamieszczania materiałów przez zarejestrowanego użytkownika forum, które mają na celu obrazy(tekst, obrazy, inne), treści erotyczne(filmy i inne), rasizmu, czy też gróźb i innych treści, które moderator uzna za niezgodne do wglądu przez publiczność forum, moderatorzy mają prawo do skasowania oraz ukrycia treści, a dodatkowo ukarania użytkownika, który zamieścił daną treść.
* Użytkownik ma prawo do wyrażania swojej opinii tylko i wyłącznie w sposób kulturalny, oraz tak, aby treść zamieszczona nie uraziła zarejestrowanych użytkowników forum.
* Błędy oraz niedopatrzenia należy zgłaszać Administratorowi Forum, zakazuje się wykorzystywania błędów dla własnych korzyści, oraz udostępniania dla osób trzecich.
* Zakaz stosowania jakichkolwiek technik mających na celu utrudnienie rozpoznania lub weryfikacji użytkownika.
* Treści na forum pisane z licznymi i celowymi błędami ortograficznymi, obrazami, wulgaryzmami skutkują karze na forum decydującej przez moderatora.
* Nadmierne używanie słów wulgarnych, wyzwiska, hejt, trollowanie - skutkuje karą nadaną przez moderatora. W powyższe punkty wchodzą rzeczy takie jak prywatne wiadomości, statusy, posty, tematy, panel gracza. Karze podlega zarówno osoba, która wykonuje powyższe czyny oraz ta, która wdaje się w działania, oraz też nakłania do działań.
* Zakazuje się umieszczanie ofert handlowych, linków w celach zarobkowych na całym forum, karą może być nawet odcięcie od dostępu do serwera SA-MP oraz forum.
* Nazwa użytkownika nie może być wulgarna i w żaden sposób prowokacyjna, zastrzega się również błędów ortograficznych.
* Na forum obowiązuje zakaz publikacji cudzych zdjęć i danych osobowych bez zgody osoby której dotyczą.

## Prawa moderatora.
* Moderator ma prawo do ukarania użytkownika, jeśli ten dopatrzy się treści niezgodnych z regulaminem forum.
* Moderator ma prawo zamknąć temat, który jest zamieszczony w złym dziale, bądź jest niezgodny z regulaminem - moderator musi dopisać argument wykonywanego czynu.
* Typ kary, oraz czas zależy od moderatora, pamiętajmy, że kara nie może być zbyt surowa:
* blokada pisania nie może przekraczać 3 dni, wraz z zawieszeniem tworzenia zawartości.
* możliwość apelowania od warnów możliwa jest po upływie dwóch dni od nadania kary przez moderatora.
* możliwość apelowania od blokady konta(ban) jest akceptowana po upływie 3 dni od nadania kary.
(czynności w/w nie dotyczą dni apelowania jeśli kara jest źle nadana)

>Informacja: Moderator jest to osoba, która wykonuje swoje obowiązki, sprawdza status przestrzegania regulaminu, reaguje na zgłoszenia oraz dba o treści zamieszczane publicznie na całym forum, jeśli uznał on, że dany użytkownik powinien otrzymać stosowną karę jest to w jego obowiązku.

## Ostrzeżenia, blokady:

* Użytkownik, który uzyskał 6 punktów ostrzeżeń otrzymuje blokadę konta na czas określony przez moderatora.
* Blokada możliwości pisania postów, statusów, tematów, kolejka moderacyjna * czas blokady zaczyna się od 1 godziny do 48 godzin, bądź do (1) jednego tygodnia * czas blokady nie może przekraczać 7 dni, czas blokady/zawieszenia użytkownika ustala moderator.
