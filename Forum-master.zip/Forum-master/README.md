![Mrucznik Role Play](http://i.imgur.com/3BFCOVu.png)

To repozytorium zawiera najważniejsze dokumenty oraz regulaminy, które mają związek z [forum Mrucznik Role Play](https://mrucznik-rp.pl/). Zawiera między innymi regulamin forum oraz czarną liste forum. Wcześniejszą historie dokumentów forum można śledzić w repozytorium [Mrucznik/Mrucznik-Docs](https://github.com/Mrucznik/Mrucznik-Docs).

## Wkład społeczności
Społeczność może przyczyniać się do ulepszania regulaminu poprzez zgłaszanie Issues lub wprowadzania własnych poprawek prze mechanizm Pull Request. Więcej informacji w pliku [CONTRIBUTING.md](https://github.com/MrucznikRolePlay/Forum/CONTRIBUTE.md)